from django.shortcuts import render

def index(request):
    return render(request, 'main/index.html')
def Kalen(request):
    return render(request, 'main/Kalen.html') #Указываем путь до нужной функции
def Films(request):
    return render(request, 'main/Films.html')
def Prob2(request):
    return render(request, 'main/Prob2.html')
def Zam(request):
    return render(request, 'main/Zam.html')
def Finans(request):
    return render(request, 'main/Finans.html')
def side(request):
    return render(request, 'main/side.html')

#def Rasp(request):
    #return HttpResponse("<h12>Тут будет расписание<h12>")
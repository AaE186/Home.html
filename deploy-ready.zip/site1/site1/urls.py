from django.contrib import admin
from django.urls import path, include

from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('main.urls'))# При переходе на главную страницу пользователя кидает в главное окно и там все появляется, делегируем короче
] + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)

